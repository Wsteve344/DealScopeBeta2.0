import React from 'react';

const AnalystDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Analyst Dashboard</h2>
      {/* TODO: List assigned deals, enter scores, generate reports */}
      <p>Manage and analyze submitted deals here.</p>
    </div>
  );
};

export default AnalystDashboard;
