import React from 'react';

const InvestorDashboard: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-4">Investor Dashboard</h2>
      {/* TODO: Show credit balance, submission form, report history */}
      <p>Welcome, investor! Submit your deals and track your reports here.</p>
    </div>
  );
};

export default InvestorDashboard;
