import React from 'react';

const CalendarBoard: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">Calendar Board</h2>
      {/* TODO: Implement drag and drop appointment calendar */}
      <p>View and manage your appointments here.</p>
    </div>
  );
};

export default CalendarBoard;
