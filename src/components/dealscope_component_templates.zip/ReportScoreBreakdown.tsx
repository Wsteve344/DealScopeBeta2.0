import React from 'react';

interface ScoreCategory {
  category: string;
  points: number;
  maxPoints: number;
}

const dummyScore: ScoreCategory[] = [
  { category: "Cash Flow", points: 10, maxPoints: 15 },
  { category: "Appreciation", points: 5, maxPoints: 10 },
  // Add remaining categories...
];

const ReportScoreBreakdown: React.FC = () => {
  const total = dummyScore.reduce((sum, s) => sum + s.points, 0);

  return (
    <div className="p-4">
      <h3 className="text-xl font-semibold mb-2">Deal Score Breakdown</h3>
      <ul>
        {dummyScore.map((score, idx) => (
          <li key={idx}>{score.category}: {score.points}/{score.maxPoints}</li>
        ))}
      </ul>
      <p className="mt-4 font-bold">Total Score: {total}/100</p>
    </div>
  );
};

export default ReportScoreBreakdown;
