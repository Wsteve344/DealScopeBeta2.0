import React from 'react';

const PipelineCRM: React.FC = () => {
  return (
    <div className="p-6">
      <h2 className="text-xl font-bold mb-4">CRM & Pipeline</h2>
      {/* TODO: Add lead management, assignments, duplicate checking */}
      <p>Manage your leads and pipeline stages here.</p>
    </div>
  );
};

export default PipelineCRM;
